# phpcrud

Trabajo de la materia Desarrollo de Software

Trabajo realizado en PHP y los estilos se están manejando con Bootstrap.

NO DEJAR LOS TRABAJOS PARA EL ULTIMO DIA
