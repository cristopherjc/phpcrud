<?php
echo password_hash("testing", PASSWORD_DEFAULT);
?>