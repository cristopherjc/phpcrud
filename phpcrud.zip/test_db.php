<?php
  require_once 'config/db.php';
  echo 'Conexion exitosa con la base de datos';
?>